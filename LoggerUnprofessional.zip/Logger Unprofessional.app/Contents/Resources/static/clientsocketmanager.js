window.addEventListener('load', function() {
    const socket = io();

    socket.on('connect', () => {
//        console.log("Connected to server.")
    });

    socket.on('disconnect', () => {
//        console.log("Disconnected from server.");
        window.open('','_self').close();
    });

    socket.on('commands', (msg) => {
        var uuid = msg.slice(0, 36);
        var cmds = msg.slice(36);
//        console.log("Received commands:", cmds);
//        console.log("UUID:", uuid);
        try {
            var result = JSON.stringify(eval(cmds));
           }
        catch (e) {
            console.log("Error:", e);
           var result = JSON.stringify(e);
        }
        finally {
//            console.log("Result:", result);
            socket.emit('results', uuid + result);
        }
    });
});